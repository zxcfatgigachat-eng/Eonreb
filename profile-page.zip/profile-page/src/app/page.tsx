"use client";

import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  FileText,
  Heart,
  Image as ImageIcon,
  Mail,
  Settings,
  Share2,
  Star,
  UserPlus,
  Users,
  Globe,
  Calendar,
  Github,
  Twitter,
  Linkedin,
  Instagram,
} from "lucide-react";

export default function ProfilePage() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <Card className="mb-6">
          <CardHeader className="pb-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
              <Avatar className="h-24 w-24 border-2 border-border">
                <AvatarImage
                  src="https://api.dicebear.com/9.x/avataaars/svg?seed=Alex"
                  alt="Аватар"
                />
                <AvatarFallback className="text-2xl">АП</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-2">
                <div>
                  <h1 className="text-2xl font-bold tracking-tight">
                    Алексей Петров
                  </h1>
                  <p className="text-muted-foreground">
                    Senior Frontend Developer
                  </p>
                  <p className="text-sm text-muted-foreground">@alexpetrov</p>
                </div>
                <p className="text-sm max-w-lg">
                  Разрабатываю современные веб-приложения с использованием
                  React, Next.js и TypeScript. Увлечён чистым кодом и
                  удобным UX.
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button variant="default" size="sm">
                  Редактировать профиль
                </Button>
                <Button variant="outline" size="sm">
                  <Share2 className="h-4 w-4" />
                  Поделиться
                </Button>
                <Button variant="ghost" size="icon">
                  <Settings className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
        </Card>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6 flex flex-col items-center text-center">
              <FileText className="h-5 w-5 text-muted-foreground mb-2" />
              <div className="text-2xl font-bold">128</div>
              <p className="text-xs text-muted-foreground">Публикации</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6 flex flex-col items-center text-center">
              <Users className="h-5 w-5 text-muted-foreground mb-2" />
              <div className="text-2xl font-bold">2.4K</div>
              <p className="text-xs text-muted-foreground">Подписчики</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6 flex flex-col items-center text-center">
              <UserPlus className="h-5 w-5 text-muted-foreground mb-2" />
              <div className="text-2xl font-bold">356</div>
              <p className="text-xs text-muted-foreground">Подписки</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6 flex flex-col items-center text-center">
              <Heart className="h-5 w-5 text-muted-foreground mb-2" />
              <div className="text-2xl font-bold">8.1K</div>
              <p className="text-xs text-muted-foreground">Лайки</p>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>О себе</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <p className="text-sm leading-relaxed text-muted-foreground">
              Более 7 лет опыта в разработке фронтенда. Специализируюсь на
              создании масштабируемых интерфейсов, оптимизации производительности
              и внедрении современных практик. Работал с командами от стартапов
              до крупных продуктов. В свободное время изучаю новые технологии,
              пишу технические статьи и участвую в open-source проектах.
              Люблю чистый код, продуманную архитектуру и внимание к деталям
              пользовательского опыта.
            </p>

            <div>
              <h3 className="text-sm font-medium mb-3">Навыки</h3>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">React</Badge>
                <Badge variant="secondary">Next.js</Badge>
                <Badge variant="secondary">TypeScript</Badge>
                <Badge variant="secondary">Tailwind CSS</Badge>
                <Badge variant="secondary">Node.js</Badge>
                <Badge variant="secondary">GraphQL</Badge>
                <Badge variant="secondary">Figma</Badge>
                <Badge variant="secondary">Git</Badge>
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Mail className="h-4 w-4" />
                <span>alex.petrov@example.com</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Globe className="h-4 w-4" />
                <a
                  href="https://alexpetrov.dev"
                  className="hover:text-foreground transition-colors"
                >
                  alexpetrov.dev
                </a>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Github className="h-4 w-4" />
                <a
                  href="https://github.com/alexpetrov"
                  className="hover:text-foreground transition-colors"
                >
                  github.com/alexpetrov
                </a>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Calendar className="h-4 w-4" />
                <span>Зарегистрирован: март 2019</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Контент</CardTitle>
            <CardDescription>
              Публикации и материалы пользователя
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="posts">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="posts">Все посты</TabsTrigger>
                <TabsTrigger value="media">Медиа</TabsTrigger>
                <TabsTrigger value="docs">Документы</TabsTrigger>
                <TabsTrigger value="fav">Избранное</TabsTrigger>
              </TabsList>
              <TabsContent value="posts" className="mt-4">
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div
                      key={i}
                      className="rounded-lg border p-4 hover:bg-muted/50 transition-colors"
                    >
                      <h4 className="font-medium mb-1">
                        Как оптимизировать производительность Next.js
                      </h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        Разбираем практики Server Components, кэширование и
                        lazy loading для быстрых приложений.
                      </p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>12 окт 2026</span>
                        <span className="flex items-center gap-1">
                          <Heart className="h-3 w-3" /> 245
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="media" className="mt-4">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <div
                      key={i}
                      className="aspect-square rounded-lg bg-muted flex items-center justify-center"
                    >
                      <ImageIcon className="h-8 w-8 text-muted-foreground" />
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="docs" className="mt-4">
                <div className="space-y-3">
                  {[
                    "Руководство по TypeScript",
                    "Архитектура фронтенда",
                    "Чек-лист код-ревью",
                  ].map((title) => (
                    <div
                      key={title}
                      className="flex items-center gap-3 rounded-lg border p-3 hover:bg-muted/50 transition-colors"
                    >
                      <FileText className="h-5 w-5 text-muted-foreground" />
                      <span className="text-sm font-medium">{title}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="fav" className="mt-4">
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <Star className="h-10 w-10 mb-3" />
                  <p className="text-sm">Избранных материалов пока нет</p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>

      <footer className="border-t mt-auto">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="h-6 w-6 rounded bg-primary flex items-center justify-center">
                <span className="text-primary-foreground text-xs font-bold">
                  N
                </span>
              </div>
              <span className="text-sm text-muted-foreground">
                © 2026 Nexus. Все права защищены
              </span>
            </div>

            <Separator orientation="vertical" className="hidden md:block h-6" />

            <div className="flex flex-wrap justify-center gap-4 text-sm">
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                О нас
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Поддержка
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Блог
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Вакансии
              </a>
            </div>

            <Separator orientation="vertical" className="hidden md:block h-6" />

            <div className="flex gap-4 text-sm">
              <a
                href="#"
                className="text-muted-foreground/70 hover:text-muted-foreground transition-colors"
              >
                Конфиденциальность
              </a>
              <a
                href="#"
                className="text-muted-foreground/70 hover:text-muted-foreground transition-colors"
              >
                Условия использования
              </a>
            </div>

            <div className="flex gap-3">
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <Github className="h-4 w-4" />
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <Linkedin className="h-4 w-4" />
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <Instagram className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
